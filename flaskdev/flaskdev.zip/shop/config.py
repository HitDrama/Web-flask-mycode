import os
import string
import random

class Config:
    SECRET_KEY = os.urandom(24)  # khóa bảo mật dùng để bảo vệ session và form
    SQLALCHEMY_DATABASE_URI = 'mysql://root@localhost/flaskdev'  # đường dẫn đến cơ sở dữ liệu
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # không theo dõi thay đổi của đối tượng

    
class EmailConfig:
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    MAIL_USERNAME = 'anhdongden15@gmail.com' # Thay bằng email của bạn
    MAIL_PASSWORD = 'ouip kxgw ubmb ovoi' # Thay bằng mật khẩu email của bạn
    MAIL_DEFAULT_SENDER = ('Flask Shop','anhdongden15@gmail.com')

def Tao_mat_khau(length = 8):
    kytu = string.ascii_letters + string.digits
    return ''.join(random.choice(kytu) for i in range(length))


class ConfigGmail:
    SECRET_KEY = os.urandom(24)  #Tạo ngẫu nhiên key: chuỗi ngẫu nhiên
    SQLALCHEMY_DATABASE_URI = 'mysql://root@localhost/flaskdev'
    GOOGLE_CLIENT_ID = '543477828678-ijino0crqobpegdoarhsvva6dcmn5vkj.apps.googleusercontent.com'
    GOOGLE_CLIENT_SECRET = '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'
    GOOGLE_ACCESS_TOKEN_URL = 'https://accounts.google.com/o/oauth2/token'
    GOOGLE_AUTHORIZE_URL = 'https://accounts.google.com/o/oauth2/auth'
    GOOGLE_USERINFO_ENDPOINT = 'https://www.googleapis.com/oauth2/v3/userinfo'
    OAUTHLIB_INSECURE_TRANSPORT = True  # Only for development